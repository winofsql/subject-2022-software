<?php

require_once( $_SERVER['DOCUMENT_ROOT'] . "/app/setting.php" );
require_once( $_SERVER['DOCUMENT_ROOT'] . "/app/connect.php" );

$conn = new PDO( $GLOBALS["connect_string"], $GLOBALS["user"], $GLOBALS["password"] );

$sql = 'SELECT name, level, job_Id FROM players ORDER BY name';
print "<pre>";
foreach ($conn->query($sql) as $row) {
	print $row['name'] . "\t";
	print $row['level'] . "\t";
	print $row['job_Id'] . "\n";
}
print "</pre>";

?>


