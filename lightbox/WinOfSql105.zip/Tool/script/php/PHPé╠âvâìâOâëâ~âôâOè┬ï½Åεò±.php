-- cli�o�[�W�������g�p���ĉ�����

$HTM
$NOCONSOLE
<HTML>
<HEAD>
<META HTTP-EQUIV="Content-Type" CONTENT="text/html; CHARSET=shift_jis">
<STYLE type="text/css">
	TABLE {
		background-color:black;
	}
	TD {
		font-family:"�l�r �o�S�V�b�N";
		font-size:12;
		background-color:white;
		color:black;
	}
</STYLE>
</HEAD>
<BODY>

<P>
<H2 width=100% style=background-color:silver>php.ini ����</H2>
<TABLE bgcolor=black cellspacing=1 cellpadding=5>
<?
	$a = get_cfg_var("cgi.force_redirect");	
	print "<TR><td><b>cgi.force_redirect</b></td><td>$a</td></TR>";

	$a = get_cfg_var("extension_dir");	
	print "<TR><td><b>extension_dir</b></td><td>$a</td></TR>";

	$a = get_cfg_var("include_path");	
	print "<TR><td><b>include_path</b></td><td>$a</td></TR>";

	$a = get_cfg_var("magic_quotes_gpc");	
	print "<TR><td><b>magic_quotes_gpc</b></td><td>$a</td></TR>";

	$a = get_cfg_var("register_globals");	
	print "<TR><td><b>register_globals</b></td><td>$a</td></TR>";

	$a = get_cfg_var("SMTP");	
	print "<TR><td><b>SMTP</b></td><td>$a</td></TR>";

?>
</TABLE>

<P>
<H2 width=100% style=background-color:silver>���[�h�ς݃��W���[���ꗗ</H2>
<TABLE bgcolor=black cellspacing=1 cellpadding=5>
<?
	$a = get_loaded_extensions();
	foreach( $a as $value ) {
		print "<TR>";
		print "<TD bgcolor=white>$value</TD>";
		print "</TR>";
	}
?>
</TABLE>

<P>
<H2 width=100% style=background-color:silver>��`�ς݃N���X�ꗗ</H2>
<TABLE bgcolor=black cellspacing=1 cellpadding=5>
<?
	$a = get_declared_classes();
	foreach( $a as $value ) {
		print "<TR>";
		print "<TD bgcolor=white>$value</TD>";
		print "</TR>";
	}
?>
</TABLE>

<P>
<H2 width=100% style=background-color:silver>$_SERVER</H2>
<TABLE bgcolor=black cellspacing=1 cellpadding=5>
<?
	foreach( $_SERVER as $key => $value ) {
		print "<TR>";
		print "<TD bgcolor=white>$key</TD>";
		print "<TD bgcolor=white>$value</TD>";
		print "</TR>";
	}
?>
</TABLE>

<P>
<H2 width=100% style=background-color:silver>�萔�ꗗ</H2>
<TABLE bgcolor=black cellspacing=1 cellpadding=5>
<?
	$a = get_defined_constants();
	print "<TABLE bgcolor=black cellspacing=1 cellpadding=5>";
	foreach( $a as $key => $value ) {
		print "<TR>";
		print "<TD bgcolor=white>$key</TD>";
		print "<TD bgcolor=white>$value</TD>";
		print "</TR>";
	}
?>
</TABLE>

</BODY>
</HTML>
