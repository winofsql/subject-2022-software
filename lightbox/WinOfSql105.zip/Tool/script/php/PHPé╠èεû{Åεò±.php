-- cli �ł͖����A�ʏ�� cgi �o�[�W�������g�p���ĉ�����

$HTM
$NOCONSOLE
<HTML>
<HEAD>
<META HTTP-EQUIV="Content-Type" CONTENT="text/html; CHARSET=shift_jis">
</HEAD>
<BODY>

<P>
<H2 width=100% style=background-color:silver>INFO_GENERAL</H2>
<? phpinfo(INFO_GENERAL) ?>

<P>
<H2 width=100% style=background-color:silver>INFO_CONFIGURATION</H2>
<? phpinfo(INFO_CONFIGURATION) ?>

<P>
<H2 width=100% style=background-color:silver>INFO_MODULES</H2>
<? phpinfo(INFO_MODULES) ?>

<P>
<H2 width=100% style=background-color:silver>INFO_ENVIRONMENT</H2>
<? phpinfo(INFO_ENVIRONMENT) ?>

<P>
<H2 width=100% style=background-color:silver>INFO_VARIABLES</H2>
<? phpinfo(INFO_VARIABLES) ?>

</BODY>
</HTML>
