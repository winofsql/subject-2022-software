<?php
print <<< MMENU
<div id="mmenu_left">
<ul>
	<li class="mm_user_title">ページ選択</li>
	<li><a class="mm_link_left" href="#" onclick="location='.';void(0)">リセット</a></li>
	<li><a class="mm_link_left"
			target="_blank"
			href="https://getbootstrap.com/docs/"
			onclick="$('#mmenu_left').data('mmenu').close();"
		>Bootstrap(css)</a></li>
	<li><a class="mm_link_left"
			target="_blank"
			href="http://api.jquery.com/"
			onclick="$('#mmenu_left').data('mmenu').close();"
			target="_blank"
		>jQuery ドキュメント</a></li>
</ul>
</div>
MMENU;
?>
