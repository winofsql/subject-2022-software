<?php
require_once("{$_SERVER["DOCUMENT_ROOT"]}/index/view_main.php");
?>
