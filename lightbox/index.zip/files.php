<?php
session_cache_limiter('nocache');
session_start();
$GLOBALS['pass'] = 'iseifu';

require_once("view_main.php");
?>
